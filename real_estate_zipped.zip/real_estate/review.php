<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';
$property_id = isset($_GET['property_id']) ? (int)$_GET['property_id'] : 0;
$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

// Fetch agent details if available
$agent = null;
if ($property_id > 0) {
    $stmt = $conn->prepare("
        SELECT a.*, u.user_type
        FROM properties p 
        JOIN users u ON p.user_id = u.user_id 
        LEFT JOIN agents a ON p.user_id = a.user_id 
        WHERE p.property_id = ?
    ");
    $stmt->bind_param("i", $property_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    if ($row && $row['user_type'] === 'agent' && !empty($row['agent_id'])) {
        $agent = $row;
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = isset($_POST['rating']) ? (float)$_POST['rating'] : 0;
    $comment = isset($_POST['comment']) ? trim($_POST['comment']) : '';
    $review_property = isset($_POST['review_property']) ? true : false;
    $review_agent = isset($_POST['review_agent']) ? true : false;

    // Validate input
    if ($user_id <= 0 || $rating < 0 || $rating > 5) {
        $message = "Invalid user ID or rating. Rating must be between 0 and 5.";
    } elseif (!$review_property && !$review_agent) {
        $message = "Please select at least one option to review (property or agent).";
    } else {
        // Handle property review
        if ($review_property && $property_id > 0) {
            $stmt = $conn->prepare("
                INSERT INTO review (user_id, property_id, rating, comment, created_at) 
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->bind_param("iids", $user_id, $property_id, $rating, $comment);
            if ($stmt->execute()) {
                $message = "Property review submitted successfully! ";
            } else {
                $message = "Error submitting property review: " . $stmt->error . " ";
            }
            $stmt->close();
        }

        // Handle agent review
        if ($review_agent && $agent && !empty($agent['agent_id'])) {
            $stmt = $conn->prepare("
                INSERT INTO agent_reviews (agent_id, user_id, rating, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->bind_param("iid", $agent['agent_id'], $user_id, $rating);
            if ($stmt->execute()) {
                $message .= "Agent review submitted successfully!";
            } else {
                $message .= "Error submitting agent review: " . $stmt->error . " ";
            }
            $stmt->close();
        } elseif ($review_agent) {
            $message .= "Error: Agent review could not be submitted because the agent ID is missing.";
        }

        if (strpos($message, "successfully") !== false) {
            header("Location: reviews.php?property_id=$property_id");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Write Review</title>
    <style>
        .review-form-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
        }
        .review-form-container h2 {
            color: #333;
            margin-bottom: 20px;
        }
        .review-form-container form {
            display: flex;
            flex-direction: column;
        }
        .review-form-container label {
            margin-bottom: 10px;
            color: #444;
        }
        .review-form-container input[type="number"],
        .review-form-container textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .review-form-container textarea {
            resize: vertical;
            min-height: 100px;
        }
        .review-form-container button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        .review-form-container button:hover {
            background-color: #218838;
        }
        .review-form-container .message {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
        }
        .review-form-container .message.success {
            background-color: #d4edda;
            color: #155724;
        }
        .review-form-container .message.error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #6c757d;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-link:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <main>
        <section class="review-form-container">
            <h2>Write a Review</h2>
            <?php if ($message): ?>
                <div class="message <?php echo strpos($message, 'success') !== false ? 'success' : 'error'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <label>
                    Review For:
                    <div>
                        <input type="checkbox" name="review_property" checked> Property
                        <?php if ($agent): ?>
                            <input type="checkbox" name="review_agent"> Agent (<?php echo htmlspecialchars($agent['agency_name']); ?>)
                        <?php endif; ?>
                    </div>
                </label>
                <label>
                    Rating (0-5):
                    <input type="number" name="rating" step="0.1" min="0" max="5" required>
                </label>
                <label>
                    Comment:
                    <textarea name="comment" placeholder="Write your review here..."></textarea>
                </label>
                <button type="submit">Submit Review</button>
            </form>
            
            <a href="reviews.php?property_id=<?php echo $property_id; ?>" class="back-link">Back to Reviews</a>
        </section>
    </main>
</body>
</html>

<?php
$conn->close();
?>