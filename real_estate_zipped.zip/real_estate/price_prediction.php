<?php
header('Content-Type: application/json'); // Ensure the response is JSON

$apiKey = 'AIzaSyBMc9ZXJN-_eSYuzQWY8p4gy5kUIt5SYA0'; // Replace with your actual Gemini API key

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read input from request
    $input = json_decode(file_get_contents('php://input'), true);
    $userMessage = $input['message'] ?? '';

    if (empty($userMessage)) {
        echo json_encode(['error' => 'Message cannot be empty.']);
        exit;
    }

    // **Prepend hardcoded prompt to user's message**
    $hardcodedPrompt = "consider you are a real estate agent located in pakistan agent and you have specialization in price predictoin 
    so considering user will tell you basic featrures of their house and location and using your existing 
    knowledge you will predict price in pkr and whatever you respond will 
    be sent to customer so make sure to respond like agent not like chatbot respond shortly and straighforward  if someone asks price estimation answers them by your estimate guess confidently and  answer like agents do remember if anyone asks anything other than real estate respond with cant tell i am real estate agent.\n";
    $message = $hardcodedPrompt . $userMessage; 

    // Prepare API request payload for Gemini
    $data = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $message]
                ]
            ]
        ]
    ];

    $jsonData = json_encode($data);

    // Initialize cURL for Gemini API
    $ch = curl_init("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey");
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json'
        ],
        CURLOPT_POSTFIELDS => $jsonData,
        CURLOPT_SSL_VERIFYPEER => false // Set to true in production
    ]);

    // Execute API request
    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo json_encode(['error' => curl_error($ch)]);
    } else {
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        // Check for successful response (200 or 201)
        if ($httpCode === 200 || $httpCode === 201) {
            $decodedResponse = json_decode($response, true);

            // Extract the bot's reply from Gemini's response
            if (isset($decodedResponse['candidates'][0]['content']['parts'][0]['text'])) {
                $botReply = $decodedResponse['candidates'][0]['content']['parts'][0]['text'];
                echo json_encode(['response' => $botReply]);
            } else {
                echo json_encode(['error' => 'Unexpected API response format.', 'api_response' => $decodedResponse]);
            }
        } else {
            echo json_encode(['error' => 'HTTP error code ' . $httpCode, 'response' => $response]);
        }
    }

    curl_close($ch);
} else {
    echo json_encode(['error' => 'Invalid request method.']);
}

?> 