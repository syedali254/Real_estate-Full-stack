// You can add any interactive JavaScript functionality here if needed
document.addEventListener('DOMContentLoaded', function() {
    // Example: Add event listeners or other interactive features
});