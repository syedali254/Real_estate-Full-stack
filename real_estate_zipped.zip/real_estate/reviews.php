<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get property_id from URL
$property_id = isset($_GET['property_id']) ? (int)$_GET['property_id'] : 0;
$property = [];
$agent = [];
$propertyReviews = [];
$agentReviews = [];
$user_id = 0;

// Fetch logged-in user's user_id
if (isset($_SESSION['username'])) {
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_id = (int)$row['user_id'];
    }
    $stmt->close();
}

// Fetch property details and check seller's user_type
if ($property_id > 0) {
    $stmt = $conn->prepare("
        SELECT p.*, l.city, l.area, l.phase, l.street, p.user_id as seller_id, u.user_type
        FROM properties p 
        JOIN Locations l ON p.location_id = l.location_id 
        JOIN users u ON p.user_id = u.user_id 
        WHERE p.property_id = ?
    ");
    $stmt->bind_param("i", $property_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $property = $result->fetch_assoc();
    $stmt->close();
    
    // Check if property exists and if seller is an agent
    if ($property && isset($property['seller_id'])) {
        if ($property['user_type'] === 'agent') {
            // Fetch agent details if seller is an agent
            $stmt = $conn->prepare("
                SELECT * FROM agents WHERE user_id = ?
            ");
            $stmt->bind_param("i", $property['seller_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            $agent = $result->fetch_assoc();
            $stmt->close();
        }
        
        // Fetch property reviews (agent_id = 0 or NULL)
        $stmt = $conn->prepare("
            SELECT r.*, u.username 
            FROM review r
            JOIN users u ON r.user_id = u.user_id
            WHERE r.property_id = ? AND (r.agent_id = 0 OR r.agent_id IS NULL)
            ORDER BY r.created_at DESC
        ");
        $stmt->bind_param("i", $property_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $propertyReviews = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Fetch agent reviews if agent exists
        if ($agent) {
            $stmt = $conn->prepare("
                SELECT r.*, u.username 
                FROM agent_reviews r
                JOIN users u ON r.user_id = u.user_id
                WHERE r.agent_id = ?
                ORDER BY r.created_at DESC
            ");
            $stmt->bind_param("i", $agent['agent_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            $agentReviews = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        }
    }
}

// Calculate average ratings
$propertyAvgRating = 0;
$propertyReviewCount = count($propertyReviews);
if ($propertyReviewCount > 0) {
    $sum = 0;
    foreach ($propertyReviews as $review) {
        $sum += $review['rating'];
    }
    $propertyAvgRating = $sum / $propertyReviewCount;
}

$agentAvgRating = 0;
$agentReviewCount = count($agentReviews);
if ($agentReviewCount > 0) {
    $sum = 0;
    foreach ($agentReviews as $review) {
        $sum += $review['rating'];
    }
    $agentAvgRating = $sum / $agentReviewCount;
}

// Helper function to display stars
function displayStars($rating) {
    $fullStar = "★";
    $emptyStar = "☆";
    $html = '';
    
    for ($i = 1; $i <= 5; $i++) {
        if ($i <= $rating) {
            $html .= '<span class="star full">' . $fullStar . '</span>';
        } else {
            $html .= '<span class="star empty">' . $emptyStar . '</span>';
        }
    }
    
    return $html;
}

// Format date
function formatDate($dateString) {
    $date = new DateTime($dateString);
    return $date->format('F j, Y');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Reviews</title>
    <link rel="stylesheet" href="listing-stye.css">
    <style>
        .reviews-container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
        }
        .reviews-container h2 {
            color: #333;
            margin-bottom: 10px;
        }
        .reviews-container h3 {
            color: #444;
            margin-top: 20px;
            margin-bottom: 15px;
            padding-bottom: 5px;
            border-bottom: 1px solid #eee;
        }
        .review-summary {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
        .review-summary p {
            margin: 5px 0;
        }
        .review-item {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .review-item .reviewer {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .review-item .rating {
            margin-bottom: 10px;
        }
        .review-item .comment {
            margin-bottom: 10px;
            line-height: 1.4;
        }
        .review-item .date {
            font-size: 0.9em;
            color: #777;
            text-align: right;
        }
        .star {
            color: #ccc;
            font-size: 20px;
        }
        .star.full {
            color: #ffcc00;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #6c757d;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-link:hover {
            background-color: #5a6268;
        }
        .add-review-link {
            display: inline-block;
            margin-top: 20px;
            margin-right: 10px;
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .add-review-link:hover {
            background-color: #218838;
        }
        .no-reviews {
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
            color: #6c757d;
            text-align: center;
            margin: 20px 0;
        }
        .tab-container {
            margin-bottom: 20px;
        }
        .tab-buttons {
            display: flex;
            border-bottom: 1px solid #ddd;
        }
        .tab-button {
            padding: 10px 20px;
            background-color: #f1f1f1;
            border: 1px solid #ddd;
            border-bottom: none;
            cursor: pointer;
            border-radius: 5px 5px 0 0;
            margin-right: 5px;
        }
        .tab-button.active {
            background-color: #fff;
            border-bottom: 1px solid #fff;
            margin-bottom: -1px;
        }
        .tab-content {
            display: none;
            padding: 15px;
            border: 1px solid #ddd;
            border-top: none;
        }
        .tab-content.active {
            display: block;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h1>Property Reviews</h1>
            <nav>
                <a href="landpage.html">Dashboard</a>
                <a href="seller_dashboard.html">Upload Property</a>
                <a href="#contactUs">Contact</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="reviews-container">
            <?php if ($property): ?>
                <h2><?php echo htmlspecialchars($property['property_type']); ?> Reviews</h2>
                <p>Location: <?php echo htmlspecialchars($property['city'] . ', ' . $property['area'] . ', ' . $property['phase'] . ', ' . $property['street']); ?></p>
                
                <div class="tab-container">
                    <div class="tab-buttons">
                        <div class="tab-button active" onclick="openTab(event, 'property-reviews')">Property Reviews</div>
                        <?php if ($agent): ?>
                        <div class="tab-button" onclick="openTab(event, 'agent-reviews')">Agent Reviews</div>
                        <?php endif; ?>
                    </div>
                
                    <div id="property-reviews" class="tab-content active">
                        <div class="review-summary">
                            <h3>Property Reviews Summary</h3>
                            <p><strong>Average Rating:</strong> <?php echo number_format($propertyAvgRating, 1); ?> / 5.0 <?php echo displayStars(round($propertyAvgRating)); ?></p>
                            <p><strong>Total Reviews:</strong> <?php echo $propertyReviewCount; ?></p>
                        </div>
                        
                        <?php if (count($propertyReviews) > 0): ?>
                            <?php foreach ($propertyReviews as $review): ?>
                                <div class="review-item">
                                    <p class="reviewer">User: <?php echo htmlspecialchars($review['username']); ?></p>
                                    <p class="rating"><?php echo displayStars($review['rating']); ?> (<?php echo $review['rating']; ?>/5)</p>
                                    <p class="comment"><?php echo htmlspecialchars($review['comment']); ?></p>
                                    <p class="date">Posted on <?php echo formatDate($review['created_at']); ?></p>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-reviews">
                                <p>No property reviews yet. Be the first to leave a review!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($agent): ?>
                    <div id="agent-reviews" class="tab-content">
                        <div class="review-summary">
                            <h3>Agent Reviews Summary</h3>
                            <p><strong>Agent:</strong> <?php echo htmlspecialchars($agent['agency_name']); ?> (<?php echo $agent['experience_years']; ?> years experience)</p>
                            <p><strong>Average Rating:</strong> <?php echo number_format($agentAvgRating, 1); ?> / 5.0 <?php echo displayStars(round($agentAvgRating)); ?></p>
                            <p><strong>Total Reviews:</strong> <?php echo $agentReviewCount; ?></p>
                        </div>
                        
                        <?php if (count($agentReviews) > 0): ?>
                            <?php foreach ($agentReviews as $review): ?>
                                <div class="review-item">
                                    <p class="reviewer">User: <?php echo htmlspecialchars($review['username']); ?></p>
                                    <p class="rating"><?php echo displayStars($review['rating']); ?> (<?php echo $review['rating']; ?>/5)</p>
                                    <p class="comment"><?php echo htmlspecialchars($review['comment']); ?></p>
                                    <p class="date">Posted on <?php echo formatDate($review['created_at']); ?></p>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-reviews">
                                <p>No agent reviews yet. Be the first to leave a review!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if ($user_id > 0): ?>
                    <a href="review.php?property_id=<?php echo $property_id; ?>&user_id=<?php echo $user_id; ?>" class="add-review-link">Write a Review</a>
                <?php endif; ?>
                <a href="property_details.php?property_id=<?php echo $property_id; ?>" class="back-link">Back to Property Details</a>
            <?php else: ?>
                <p>Property not found.</p>
                <a href="listings.php" class="back-link">Back to Listings</a>
            <?php endif; ?>
        </section>
    </main>

    <footer id="contactUs">
        <div class="footer-content">
            <p>For inquiries, contact us at <a href="mailto:support@sellerdashboard.com">support@sellerdashboard.com</a>.</p>
            <p>© 2025 Seller Dashboard. All rights reserved.</p>
        </div>
    </footer>

    <script>
    function openTab(evt, tabName) {
        var i, tabcontent, tabbuttons;
        
        // Hide all tab content
        tabcontent = document.getElementsByClassName("tab-content");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].className = tabcontent[i].className.replace(" active", "");
        }
        
        // Remove active class from all tab buttons
        tabbuttons = document.getElementsByClassName("tab-button");
        for (i = 0; i < tabbuttons.length; i++) {
            tabbuttons[i].className = tabbuttons[i].className.replace(" active", "");
        }
        
        // Show the current tab and add active class to the button
        document.getElementById(tabName).className += " active";
        evt.currentTarget.className += " active";
    }
    </script>
</body>
</html>

<?php
$conn->close();
?>