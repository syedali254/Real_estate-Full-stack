CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100),
  email VARCHAR(100),
  password VARCHAR(255),
  user_type VARCHAR(50),
  phone VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE locations (
  location_id INT AUTO_INCREMENT PRIMARY KEY,
  city VARCHAR(100),
  area VARCHAR(100),
  phase VARCHAR(50),
  street VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE properties (
  property_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  location_id INT,
  property_type VARCHAR(100),
  status VARCHAR(50),
  size_marla FLOAT,
  price DECIMAL(15,2),
  bedrooms INT,
  bathrooms INT,
  floors INT,
  description TEXT,
  listed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (location_id) REFERENCES locations(location_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE property_images (
  image_id INT AUTO_INCREMENT PRIMARY KEY,
  property_id INT,
  image_url VARCHAR(255),
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE property_features (
  feature_id INT AUTO_INCREMENT PRIMARY KEY,
  property_id INT,
  feature_name VARCHAR(100),
  feature_value VARCHAR(255),
  FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE property_amenities (
  amenity_id INT AUTO_INCREMENT PRIMARY KEY,
  property_id INT,
  amenity_type VARCHAR(100),
  amenity_name VARCHAR(100),
  distance_km FLOAT,
  FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE property_categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  property_id INT,
  FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE favorites (
  favorite_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  property_id INT,
  saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE schedule_visit (
  visit_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  property_id INT,
  scheduled_date DATE,
  status VARCHAR(50),
  owner_user_id INT,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (owner_user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE review (
  review_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  property_id INT,
  agent_id INT,
  rating INT,
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE,
  FOREIGN KEY (agent_id) REFERENCES agents(agent_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE agents (
  agent_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  phone VARCHAR(20)
) ENGINE=InnoDB;

CREATE TABLE agent_reviews (
  review_id INT AUTO_INCREMENT PRIMARY KEY,
  agent_id INT,
  user_id INT,
  rating INT,
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100)
) ENGINE=InnoDB;