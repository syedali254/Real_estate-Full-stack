<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = 0;
if (isset($_SESSION['username'])) {
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_id = (int)$row['user_id'];
    }
    $stmt->close();
}

$favorites = [];
if ($user_id > 0) {
    $stmt = $conn->prepare("
        SELECT f.*, p.*, l.city, l.area, 
               (SELECT pi.image_url 
                FROM property_images pi 
                WHERE pi.property_id = p.property_id 
                ORDER BY pi.uploaded_at DESC 
                LIMIT 1) AS image_url
        FROM favorites f
        JOIN properties p ON f.property_id = p.property_id
        JOIN Locations l ON p.location_id = l.location_id
        WHERE f.user_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $favorites = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favorite Properties</title>
    <link rel="stylesheet" href="listing-stye.css">
    <style>
        .favorites-container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
        }
        .favorite-card {
            display: flex;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
        }
        .favorite-img {
            max-width: 150px;
            height: auto;
            margin-right: 15px;
        }
        .favorite-info {
            flex-grow: 1;
        }
        .favorite-info h3 {
            color: #333;
            margin-bottom: 5px;
        }
        .favorite-info p {
            margin: 5px 0;
            color: #666;
        }
        .view-details {
            display: inline-block;
            padding: 5px 10px;
            background-color: #007BFF;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .view-details:hover {
            background-color: #0056b3;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #6c757d;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-link:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h1>Favorite Properties</h1>
            <nav>
                <a href="landpage.html">Dashboard</a>
                <a href="listings.php">Property Listings</a>
                <a href="#contactUs">Contact</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="favorites-container">
            <h2>Your Favorite Properties</h2>
            <?php
            if (count($favorites) > 0) {
                foreach ($favorites as $favorite) {
                    echo "<div class='favorite-card'>";
                    echo "<img src='" . htmlspecialchars($favorite['image_url'] ?? 'placeholder.jpg') . "' alt='Property Image' class='favorite-img'>";
                    echo "<div class='favorite-info'>";
                    echo "<h3>" . htmlspecialchars($favorite['property_type']) . "</h3>";
                    echo "<p class='property-location'>" . htmlspecialchars($favorite['city'] . ', ' . $favorite['area']) . "</p>";
                    echo "<p class='property-price'>PKR " . number_format($favorite['price'], 2) . " Crore</p>";
                    echo "<p class='saved-date'>Saved on: " . htmlspecialchars($favorite['saved_at']) . "</p>";
                    echo "<a href='property_details.php?property_id=" . htmlspecialchars($favorite['property_id']) . "' class='view-details'>View Details</a>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "<p>No favorite properties found. Add some from the listings!</p>";
                if ($user_id <= 0) {
                    echo "<p>Please log in to view your favorites.</p>";
                }
            }
            ?>
            <a href="listings.php" class="back-link">Back to Listings</a>
        </section>
    </main>

    <footer id="contactUs">
        <div class="footer-content">
            <p>For inquiries, contact us at <a href="mailto:support@sellerdashboard.com">support@sellerdashboard.com</a>.</p>
            <p>© 2025 Seller Dashboard. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

<?php
$conn->close();
?>