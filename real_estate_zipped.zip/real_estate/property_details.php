<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get property_id from URL
$property_id = isset($_GET['property_id']) ? (int)$_GET['property_id'] : 0;
$property = [];
$images = [];
$amenities = [];
$features = [];
$user = [];
$user_id = 0;

if ($property_id > 0) {
   
    $stmt = $conn->prepare("
        SELECT p.*, l.city, l.area, l.phase, l.street 
        FROM properties p 
        JOIN Locations l ON p.location_id = l.location_id 
        WHERE p.property_id = ?
    ");
    $stmt->bind_param("i", $property_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $property = $result->fetch_assoc();
    $stmt->close();

    // Fetch property images
    $stmt = $conn->prepare("
        SELECT image_url 
        FROM property_images 
        WHERE property_id = ? 
        ORDER BY uploaded_at DESC
    ");
    $stmt->bind_param("i", $property_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $images = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Fetch amenities
    $stmt = $conn->prepare("
        SELECT amenity_type, amenity_name, distance_km 
        FROM property_amenities 
        WHERE property_id = ?
    ");
    $stmt->bind_param("i", $property_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $amenities = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Fetch features
    $stmt = $conn->prepare("
        SELECT feature_name, feature_value 
        FROM property_features 
        WHERE property_id = ?
    ");
    $stmt->bind_param("i", $property_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $features = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Fetch user details
    if ($property && isset($property['user_id']) && $property['user_id'] > 0) {
        $stmt = $conn->prepare("
            SELECT username, email, phone 
            FROM users 
            WHERE user_id = ?
        ");
        $stmt->bind_param("i", $property['user_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        if (!$user) {
            error_log("No user found for user_id: " . $property['user_id']);
        }
    } else {
        error_log("No valid user_id found for property_id: $property_id");
    }

    // Fetch user_id based on logged-in username
    if (isset($_SESSION['username'])) {
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
        $stmt->bind_param("s", $_SESSION['username']);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $user_id = (int)$row['user_id'];
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details</title>
    <link rel="stylesheet" href="listing-stye.css">
    <style>
        .property-details {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
        }
        .property-details img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .property-details h2 {
            color: #333;
        }
        .property-details h3 {
            color: #444;
            margin-top: 20px;
        }
        .property-details p {
            margin: 10px 0;
            color: #666;
        }
        .property-details ul {
            list-style-type: none;
            padding: 0;
        }
        .property-details ul li {
            margin: 5px 0;
            color: #666;
        }
        .property-details .back-link, .property-details .review-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .property-details .back-link:hover, .property-details .review-link:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h1>Seller Dashboard - Property Details</h1>
            <nav>
                <a href="landpage.html">Dashboard</a>
                <a href="seller_dashboard.html">Upload Property</a>
                <a href="#contactUs">Contact</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="property-details">
            <?php if ($property): ?>
                <?php if (count($images) > 0): ?>
                    <?php foreach ($images as $image): ?>
                        <img src="<?php echo htmlspecialchars($image['image_url']); ?>" alt="Property Image">
                    <?php endforeach; ?>
                <?php else: ?>
                    <img src="placeholder.jpg" alt="Property Image">
                <?php endif; ?>
                
                <h2><?php echo htmlspecialchars($property['property_type']); ?></h2>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($property['city'] . ', ' . $property['area'] . ', ' . $property['phase'] . ', ' . $property['street']); ?></p>
                <p><strong>Price:</strong> PKR <?php echo number_format($property['price'], 2); ?> Crore</p>
                <p><strong>Size (Marla):</strong> <?php echo htmlspecialchars($property['size_marla'] ?? 'N/A'); ?></p>
                <p><strong>Bedrooms:</strong> <?php echo htmlspecialchars($property['bedrooms'] ?? 'N/A'); ?></p>
                <p><strong>Bathrooms:</strong> <?php echo htmlspecialchars($property['bathrooms'] ?? 'N/A'); ?></p>
                <p><strong>Floors:</strong> <?php echo htmlspecialchars($property['floors'] ?? 'N/A'); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($property['status'] ?? 'N/A'); ?></p>
                <p><strong>Description:</strong> <?php echo htmlspecialchars($property['description'] ?? 'No description available'); ?></p>

                <!-- User Details -->
                <h3>Seller Information</h3>
                <?php if ($user): ?>
                    <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username'] ?? 'N/A'); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email'] ?? 'N/A'); ?></p>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></p>
                <?php else: ?>
                    <p>No seller information available.</p>
                <?php endif; ?>

                <!-- Amenities -->
                <h3>Amenities</h3>
                <?php if (count($amenities) > 0): ?>
                    <ul>
                        <?php foreach ($amenities as $amenity): ?>
                            <li>
                                <?php echo htmlspecialchars($amenity['amenity_name']); ?> 
                                (Type: <?php echo htmlspecialchars($amenity['amenity_type']); ?>, 
                                Distance: <?php echo htmlspecialchars($amenity['distance_km'] ?? 'N/A'); ?> km)
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>No amenities available.</p>
                <?php endif; ?>

                <!-- Features -->
                <h3>Property Features</h3>
                <?php if (count($features) > 0): ?>
                    <ul>
                        <?php foreach ($features as $feature): ?>
                            <li>
                                <?php echo htmlspecialchars($feature['feature_name']); ?> 
                                (Value: <?php echo htmlspecialchars($feature['feature_value'] ?? 'N/A'); ?>)
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>No features available.</p>
                <?php endif; ?>

                <a href="listings.php" class="back-link">Back to Listings</a>
                <?php if (isset($_SESSION['username']) && $property_id > 0 && $user_id > 0): ?>
                    <a href="review.php?property_id=<?php echo $property_id; ?>&user_id=<?php echo $user_id; ?>" class="review-link">Write Review</a>
                <?php endif; ?>
            <?php else: ?>
                <p>No property details found.</p>
                <a href="listings.php" class="back-link">Back to Listings</a>
            <?php endif; ?>
            <?php if (isset($_SESSION['username']) && $property_id > 0 && $user_id > 0): ?>
    <a href="schedule_visit.php?property_id=<?php echo $property_id; ?>&user_id=<?php echo $user_id; ?>" class="review-link">Schedule Visit</a>
<?php endif; ?>
        </section>
    </main>

    <footer id="contactUs">
        <div class="footer-content">
            <p>For inquiries, contact us at <a href="mailto:support@sellerdashboard.com">support@sellerdashboard.com</a>.</p>
            <p>© 2025 Seller Dashboard. All rights reserved.</p>
        </div>
    </footer>

    <script src="filter_search.js"></script>
</body>
</html>

<?php
$conn->close();
?>