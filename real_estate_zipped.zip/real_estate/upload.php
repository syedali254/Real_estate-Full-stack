<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure user is logged in and get user_id from username
if (!isset($_SESSION['username'])) {
    die("Error: User not logged in. Please log in to upload a property.");
}

$user_id = 0;
$stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
$stmt->bind_param("s", $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $user_id = (int)$row['user_id'];
}
$stmt->close();

if ($user_id === 0) {
    die("Error: Could not find user ID for username: " . htmlspecialchars($_SESSION['username']));
}

// Get and sanitize data
$property_type = $_POST['property_type'] ?? '';
$status = $_POST['status'] ?? '';
$size_marla = $_POST['size_marla'] ?? '';
$price = $_POST['price'] ?? '';
$bedrooms = $_POST['bedrooms'] ?? null;
$bathrooms = $_POST['bathrooms'] ?? null;
$floors = $_POST['floors'] ?? null;
$description = $_POST['description'] ?? '';

$city = $_POST['city'] ?? '';
$area = $_POST['area'] ?? '';
$phase = $_POST['phase'] ?? '';
$street = $_POST['street'] ?? '';

// Insert location
$stmt = $conn->prepare("INSERT INTO Locations (city, area, phase, street) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $city, $area, $phase, $street);
$stmt->execute();
$location_id = $stmt->insert_id;
$stmt->close();

// Insert property with user_id
$stmt = $conn->prepare("INSERT INTO properties (user_id, property_type, status, size_marla, price, bedrooms, bathrooms, floors, description, location_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issddiissi", $user_id, $property_type, $status, $size_marla, $price, $bedrooms, $bathrooms, $floors, $description, $location_id);
$stmt->execute();
$property_id = $stmt->insert_id;
$stmt->close();

// Get valid category_ids from categories table
$valid_categories = [];
$result = $conn->query("SELECT category_id FROM categories");
while ($row = $result->fetch_assoc()) {
    $valid_categories[] = $row['category_id'];
}

// Insert categories
if (!empty($_POST['categories'])) {
    $stmt = $conn->prepare("INSERT INTO property_categories (property_id, category_id) VALUES (?, ?)");
    foreach ($_POST['categories'] as $category_id) {
        if (in_array($category_id, $valid_categories)) {
            $stmt->bind_param("ii", $property_id, $category_id);
            $stmt->execute();
        } else {
            echo "Warning: Invalid category_id '$category_id' skipped.<br>";
        }
    }
    $stmt->close();
}

// Insert features
if (!empty($_POST['features'])) {
    $stmt = $conn->prepare("INSERT INTO property_features (property_id, feature_name, feature_value) VALUES (?, ?, ?)");
    foreach ($_POST['features'] as $feature) {
        $fname = $feature['name'] ?? '';
        $fvalue = $feature['value'] ?? '';
        if ($fname && $fvalue) {
            $stmt->bind_param("iss", $property_id, $fname, $fvalue);
            $stmt->execute();
        }
    }
    $stmt->close();
}

// Insert amenities
if (!empty($_POST['amenities'])) {
    $stmt = $conn->prepare("INSERT INTO property_amenities (property_id, amenity_type, amenity_name, distance_km) VALUES (?, ?, ?, ?)");
    foreach ($_POST['amenities'] as $amenity) {
        $type = $amenity['type'] ?? '';
        $name = $amenity['name'] ?? '';
        $distance = $amenity['distance'] ?? '';
        if ($type && $name && $distance !== '') {
            $stmt->bind_param("issd", $property_id, $type, $name, $distance);
            $stmt->execute();
        }
    }
    $stmt->close();
}

// Upload and save images
$upload_dir = "uploads/";
if (!empty($_FILES['images']['name'][0])) {
    $stmt = $conn->prepare("INSERT INTO property_images (property_id, image_url) VALUES (?, ?)");

    foreach ($_FILES['images']['tmp_name'] as $index => $tmp_name) {
        $original_name = basename($_FILES['images']['name'][$index]);
        $new_name = time() . "_" . preg_replace("/[^a-zA-Z0-9.]/", "_", $original_name);
        $target_path = $upload_dir . $new_name;

        if (move_uploaded_file($tmp_name, $target_path)) {
            $stmt->bind_param("is", $property_id, $target_path);
            $stmt->execute();
        }
    }

    $stmt->close();
}

echo "Property submitted successfully!";
$conn->close();
?>