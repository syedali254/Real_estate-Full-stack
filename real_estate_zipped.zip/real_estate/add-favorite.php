<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    $message = "Please log in to add favorites.";
} else {
    $user_id = 0;
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_id = (int)$row['user_id'];
    }
    $stmt->close();

    if ($user_id <= 0) {
        $message = "Invalid user session.";
    } else {
        $property_id = isset($_POST['property_id']) ? (int)$_POST['property_id'] : 0;

        // Check if property exists
        $stmt = $conn->prepare("SELECT property_id FROM properties WHERE property_id = ?");
        $stmt->bind_param("i", $property_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            $message = "Property not found.";
        } else {
            // Check if already favorited
            $stmt = $conn->prepare("SELECT favorite_id FROM favorites WHERE user_id = ? AND property_id = ?");
            $stmt->bind_param("ii", $user_id, $property_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $message = "This property is already in your favorites.";
            } else {
                // Insert new favorite
                $stmt = $conn->prepare("INSERT INTO favorites (user_id, property_id, saved_at) VALUES (?, ?, NOW())");
                $stmt->bind_param("ii", $user_id, $property_id);
                if ($stmt->execute()) {
                    $message = "Property added to favorites!";
                } else {
                    $message = "Error adding to favorites: " . $stmt->error;
                }
                $stmt->close();
            }
        }
       
    }
}

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Add Favorite</title></head><body>";
echo "<p>$message</p>";
echo "<a href='listings.php'>Back to Listings</a>";
echo "</body></html>";

$conn->close();
?>