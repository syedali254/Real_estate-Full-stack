<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$minPrice = $maxPrice = $propertyName = "";
$properties = [];

// Fetch user_id if logged in
$user_id = 0;
if (isset($_SESSION['username'])) {
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_id = (int)$row['user_id'];
    }
    $stmt->close();
}

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $minPrice = isset($_POST['minPrice']) ? (float) $_POST['minPrice'] : 0;
    $maxPrice = isset($_POST['maxPrice']) ? (float) $_POST['maxPrice'] : PHP_INT_MAX;
    $propertyName = isset($_POST['propertyName']) ? '%' . $_POST['propertyName'] . '%' : '%%';

    // Fetch filtered properties with image using a subquery
    $stmt = $conn->prepare("
        SELECT p.*, l.city, l.area, 
               (SELECT pi.image_url 
                FROM property_images pi 
                WHERE pi.property_id = p.property_id 
                ORDER BY pi.uploaded_at DESC 
                LIMIT 1) AS image_url
        FROM properties p
        JOIN Locations l ON p.location_id = l.location_id
        WHERE p.property_type LIKE ? AND p.price BETWEEN ? AND ?
    ");
    $stmt->bind_param("sdd", $propertyName, $minPrice, $maxPrice);
    $stmt->execute();
    $result = $stmt->get_result();
    $properties = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    // Fetch all properties by default with image
    $sql = "
        SELECT p.*, l.city, l.area, 
               (SELECT pi.image_url 
                FROM property_images pi 
                WHERE pi.property_id = p.property_id 
                ORDER BY pi.uploaded_at DESC 
                LIMIT 1) AS image_url
        FROM properties p
        JOIN Locations l ON p.location_id = l.location_id
    ";
    $result = $conn->query($sql);
    $properties = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Listings</title>
    <link rel="stylesheet" href="listing-stye.css">
    <style>
        .favorite-btn {
            padding: 5px 10px;
            background-color: #dc3545;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 5px;
        }
        .favorite-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h1>Seller Dashboard - Property Listings</h1>
            <nav>
                <a href="landpage.html">Dashboard</a>
                <a href="seller_dashboard.html">Upload Property</a>
                <a href="#contactUs">Contact</a>
            </nav>
        </div>
    </header>

    <main>
        <section id="propertyListings">
            <h2>Available Properties</h2>

            <!-- Filter Form -->
            <form method="POST" class="property-filter">
                <label for="propertyName">Property Name:</label>
                <input type="text" name="propertyName" id="propertyName" value="<?php echo htmlspecialchars(isset($_POST['propertyName']) ? $_POST['propertyName'] : ''); ?>" placeholder="Enter property type">

                <label for="minPrice">Minimum Price:</label>
                <input type="number" name="minPrice" id="minPrice" value="<?php echo htmlspecialchars($minPrice); ?>" required>

                <label for="maxPrice">Maximum Price:</label>
                <input type="number" name="maxPrice" id="maxPrice" value="<?php echo htmlspecialchars($maxPrice); ?>" required>

                <button type="submit">Filter</button>
            </form>

            <!-- Property Listings -->
            <div class="properties-container">
                <?php
                if (count($properties) > 0) {
                    foreach ($properties as $row) {
                        echo "<div class='property-card'>";
                        echo "<img src='" . htmlspecialchars($row['image_url'] ?? 'placeholder.jpg') . "' alt='Property Image' class='property-img'>";
                        echo "<div class='property-info'>";
                        echo "<h3>" . htmlspecialchars($row['property_type']) . "</h3>";
                        echo "<p class='property-location'>" . htmlspecialchars($row['city'] . ', ' . $row['area']) . "</p>";
                        echo "<p class='property-price'>PKR " . number_format($row['price'], 2) . " Crore</p>";
                        echo "<a href='property_details.php?property_id=" . htmlspecialchars($row['property_id']) . "' class='view-details'>View Details</a>";
                        if ($user_id > 0) {
                            echo "<form action='add-favorite.php' method='POST' style='display:inline;'>";
                            echo "<input type='hidden' name='property_id' value='" . htmlspecialchars($row['property_id']) . "'>";
                            echo "<button type='submit' class='favorite-btn'>Favorite</button>";
                            echo "</form>";
                        }
                        echo "</div>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No properties found matching the specified criteria.</p>";
                }
                ?>
            </div>
        </section>
    </main>

    <footer id="contactUs">
        <div class="footer-content">
            <p>For inquiries, contact us at <a href="mailto:support@sellerdashboard.com">support@sellerdashboard.com</a>.</p>
            <p>© 2025 Seller Dashboard. All rights reserved.</p>
        </div>
    </footer>

   
</body>
</html>

<?php
$conn->close();
?>