// Check for speech synthesis support
if (!("speechSynthesis" in window)) {
    console.error("Speech synthesis not supported in this browser.");
} else {
    console.log("Speech synthesis is supported.");
}

// Handle form submission
document.getElementById("chat-form").addEventListener("submit", async function (e) {
    e.preventDefault();

    let userInput = document.getElementById("user-input").value;
    let chatBox = document.getElementById("chat-box");

    // Append user's message
    chatBox.innerHTML += `<div class="user-message">${userInput}</div>`;


    // Send the user's input to PHP for processing
    let response = await fetch("price_prediction.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userInput })
    });

    let data = await response.json();
    let botReply = data.response || "Sorry, I didn't understand.";
    console.log("Bot Reply:", botReply);

    // Append bot's message
    chatBox.innerHTML += `<div class="bot-message">${botReply}</div>`;


    // Speak the response
    setTimeout(() => {
        // ✅ Using ResponsiveVoice.js (if available)
        if (typeof responsiveVoice !== "undefined") {
            console.log("Using ResponsiveVoice.js...");
            responsiveVoice.speak(botReply, "UK English Female", {
                onstart: () => console.log("Speech started"),
                onend: () => console.log("Speech ended"),
                onerror: (err) => console.error("Speech error:", err)
            });
        }
        // ✅ Fallback to Browser's Built-in Speech Synthesis
        else if ("speechSynthesis" in window) {
            console.warn("ResponsiveVoice.js not found! Using built-in speech synthesis.");

            let speech = new SpeechSynthesisUtterance(botReply);
            speech.lang = "en-GB";
            speech.pitch = 1;
            speech.rate = 1;

            speech.onstart = () => console.log("Speech started");
            speech.onend = () => console.log("Speech ended");
            speech.onerror = (err) => console.error("Speech error:", err);

            window.speechSynthesis.cancel(); // Stop any previous speech
            window.speechSynthesis.speak(speech);
        } else {
            console.error("No speech synthesis available.");
        }
    }, 500);

    // Clear input field
    document.getElementById("user-input").value = "";
});

// 🛠 Fix Browser Speech Autoplay Issue
document.body.addEventListener("click", () => {
    let unlockSpeech = new SpeechSynthesisUtterance("Voice activated");
    window.speechSynthesis.speak(unlockSpeech);
    console.log("Speech unlocked");
}, { once: true });