<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user_id from session
$user_id = 0;
if (isset($_SESSION['username'])) {
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_id = (int)$row['user_id'];
    }
    $stmt->close();
}

if ($user_id === 0) {
    die("Error: User not logged in or invalid user.");
}

// Get property_id from URL
$property_id = isset($_GET['property_id']) ? (int)$_GET['property_id'] : 0;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $scheduled_date = $_POST['scheduled_date'] ?? '';
    if ($user_id > 0 && $property_id > 0 && !empty($scheduled_date)) {
        $stmt = $conn->prepare("INSERT INTO schedule_visit (user_id, property_id, scheduled_date, status) VALUES (?, ?, ?, 'Pending')");
        $stmt->bind_param("iis", $user_id, $property_id, $scheduled_date);
        if ($stmt->execute()) {
            $message = "Visit scheduled successfully!";
        } else {
            $message = "Error scheduling visit: " . $conn->error;
        }
        $stmt->close();
    } else {
        $message = "Invalid input. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule Visit</title>
    <link rel="stylesheet" href="listing-stye.css">
    <style>
        .schedule-form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .schedule-form label {
            display: block;
            margin-bottom: 5px;
        }
        .schedule-form input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
        .schedule-form button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .schedule-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h1>Seller Dashboard - Schedule Visit</h1>
            <nav>
                <a href="dashboard.php">Dashboard</a>
                <a href="seller_dashboard.html">Upload Property</a>
                <a href="#contactUs">Contact</a>
                <a href="logout.php">Logout</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="schedule-form">
            <h2>Schedule a Visit</h2>
            <?php if (isset($message)) echo "<p>$message</p>"; ?>
            <form method="POST">
                <label for="scheduled_date">Select Date and Time:</label>
                <input type="datetime-local" name="scheduled_date" id="scheduled_date" required>
                <button type="submit">Schedule</button>
            </form>
        </section>
    </main>

    <footer id="contactUs">
        <div class="footer-content">
            <p>For inquiries, contact us at <a href="mailto:support@sellerdashboard.com">support@sellerdashboard.com</a>.</p>
            <p>© 2025 Seller Dashboard. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

<?php
$conn->close();
?>