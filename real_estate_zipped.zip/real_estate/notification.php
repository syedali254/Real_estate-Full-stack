<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = 0;
if (isset($_SESSION['username'])) {
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_id = (int)$row['user_id'];
    }
    $stmt->close();
}

if ($user_id === 0) {
    die("Error: User not logged in or invalid user.");
}

$notifications = [];
if ($user_id > 0) {
    $stmt = $conn->prepare("SELECT sv.visit_id, p.property_type, l.city, sv.scheduled_date, sv.status 
                           FROM schedule_visit sv 
                           JOIN properties p ON sv.property_id = p.property_id 
                           JOIN locations l ON p.location_id = l.location_id 
                           WHERE sv.user_id = ? 
                           ORDER BY sv.scheduled_date DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="listing-stye.css">
    <style>
        .dashboard {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
        }
        .notification {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h1>Seller Dashboard</h1>
            <nav>
                <a href="listings.php">Properties</a>
                <a href="seller_dashboard.html">Upload Property</a>
                <a href="#contactUs">Contact</a>
                <a href="logout.php">Logout</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="dashboard">
            <h2>Notifications</h2>
            <?php if (count($notifications) > 0): ?>
                <?php foreach ($notifications as $note): ?>
                    <div class="notification">
                        <p>Visit scheduled for <strong><?php echo htmlspecialchars($note['property_type']); ?></strong> in <strong><?php echo htmlspecialchars($note['city']); ?></strong> on <strong><?php echo htmlspecialchars($note['scheduled_date']); ?></strong> (Status: <strong><?php echo htmlspecialchars($note['status']); ?></strong>)</p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No scheduled visits.</p>
            <?php endif; ?>
        </section>
    </main>

    <footer id="contactUs">
        <div class="footer-content">
            <p>For inquiries, contact us at <a href="mailto:support@sellerdashboard.com">support@sellerdashboard.com</a>.</p>
            <p>© 2025 Seller Dashboard. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

<?php
$conn->close();
?>